import {router} from "../router.js";
import {auth} from "../auth.js";

// =====================================================================================================================


// Manage customer account
$(document).on('click', '#navMyProfile a', async function(e) {
    e.preventDefault();
    await router("customer/account/customer-account.html");

    // loadCustomerDetails();
});


// =====================================================================================================================


// Manage customer address
$(document).on('click', '#navManageAddress a', async function(e) {
    e.preventDefault();
    await router("customer/account/customize-address.html");

    // loadCustomerDetails();
});


// =====================================================================================================================


// Manage customer orders
$(document).on('click', '#navMyOrders a', async function(e) {
    e.preventDefault();
    await router("customer/account/your-orders.html");

    // loadCustomerDetails();
});


// =====================================================================================================================


// Manage customer reviews
$(document).on('click', '#navMyReviews a', async function(e) {
    e.preventDefault();
    await router("customer/account/your-reviews.html");

    // loadCustomerDetails();
});


// =====================================================================================================================


// Handle logout
$(document).on('click', '#navAccountLogout a', function (e) {
    e.preventDefault();
    auth.logout();
});